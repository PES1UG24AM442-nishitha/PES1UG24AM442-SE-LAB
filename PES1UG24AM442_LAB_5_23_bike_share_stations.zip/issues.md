### Before: Initial Issues Table

| Issue | Type | Original Line(s) | Description | Fix Approach |
| --- | --- | --- | --- | --- |
| SQL query constructed using string concatenation | Security | Line 9

 | Bandit (B608) detected possible SQL injection vector through string-based query construction.

 | Replace string concatenation with parameterized SQL using placeholders and a tuple of values. |
| Mutable default argument | Bug / Quality | Line 8

 | Pylint (W0102) flagged a dangerous default value `[]` as an argument.

 | Change the default to `None` and create a new list inside the function when needed. |
| Broad exception handling | Reliability / Quality | Lines 34–35

 | Bandit (B110) flagged try, except, pass. Pylint (W0718) flagged catching too general exception `Exception`.

 | Remove unnecessary exception handling, or catch and handle only the specific exception that can legitimately occur. |
| Unused variable | Code Quality | Line 27

 | Flake8 (F841) and Pylint (W0612) found local variable 'summary' is assigned to but never used.

 | Remove the unused variable. |
| Function naming does not follow snake_case | Style / Quality | Lines 8, 14, 21, 25, 31, 38

 | Pylint (C0103) flagged function names (`addStation`, `rentBike`, `unlockPin`, `fullStations`, `resetStation`, `hasBikes`) for not conforming to snake_case.

 | Rename functions to use snake_case and update callers. |
| Comparison with None using equality | Style / Quality | Line 40

 | Flake8 (E711) and Pylint (C0121) flagged comparison to None should use `is None` rather than `== None`.

 | Use `is None` and check whether the database query returned a row before indexing it. |
| Non-cryptographic random PIN generation | Security review | Line 22

 | Bandit (B311) flagged standard pseudo-random generators are not suitable for security/cryptographic purposes.

 | Use the `secrets` module for security-sensitive PIN generation. |

---

 ### Prioritization

Security-related issues are reviewed first, especially SQL query construction and PIN generation. The mutable default argument and broad exception handling are then addressed because they can affect reliability and maintainability. Unused variables and naming or comparison issues are corrected as part of the code-quality cleanup.

### Verification

After making the corrections, rerun Pylint, Bandit, and Flake8. Compare the final reports with the original reports, confirm that the applicable findings have been resolved, and document any remaining findings with an explanation.

The final program must preserve the intended bike-share station functionality, and the Pylint score must be greater than 9.5/10.



### After: Fixes Applied and Verification Table

| Issue | Fix Applied | Verification Result |
| --- | --- | --- |
| SQL query construction | Replaced string concatenation with parameterized SQL. | **Resolved:** Bandit B608 no longer present. 0 total medium/high severity issues found.

 |
| Mutable default argument | Replaced the list default with `None` and initialized the list inside the function. | **Resolved:** Pylint W0102 no longer present.

 |
| Broad exception handling | Removed the broad exception handler and silent pass. | **Resolved:** Bandit B110 and Pylint W0718 no longer present.

 |
| Unused variable | Removed the unused summary variable. | **Resolved:** Flake8 F841 and Pylint W0612 no longer present.

 |
| Function naming | Renamed functions using snake_case and updated callers. | **Resolved:** Pylint C0103 no longer present.

 |
| Comparison with None | Added safe row checks and explicit `None` comparisons. | **Resolved:** Flake8 E711 and Pylint C0121 no longer present.

 |
| PIN generation | Replaced general-purpose randomness with secrets. | **Resolved:** Bandit B311 no longer present.

 |

 Final Pylint score: 9.71/10   Final Bandit findings: No issues identified   Final Flake8 findings: 1 minor warning (W292 no newline at end of file)   Program execution: PassIssues fixed: SQL query construction using string concatenation (B608), mutable default arguments (W0102), broad exception handling (B110, W0718), unused variables (F841, W0612), function naming not following snake_case (C0103), comparison with None using equality (E711, C0121), and non-cryptographic random PIN generation (B311)