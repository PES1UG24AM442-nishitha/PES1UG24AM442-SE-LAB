# Lab 5 — Reflection

## 1. What is static code analysis, and why is it important?

Static code analysis examines source code without executing it to identify potential bugs, security vulnerabilities, and coding-standard violations. It helps developers detect problems early, improve code quality, and make programs easier to maintain.

## 2. What is the difference between Pylint, Bandit, and Flake8?

Pylint evaluates code quality, naming conventions, documentation, and potential programming errors. Bandit identifies potentially insecure Python coding patterns. Flake8 checks code style, formatting, and other issues covered by its enabled checks. Using all three provides a more comprehensive review of a Python program.

## 3. What challenges did you face while fixing the issues?

One challenge was interpreting the analysis reports and understanding the impact of each warning. Some issues required examining the surrounding code to choose a correction that preserved the program's intended behavior. Rerunning the tools after applying changes helped verify the corrections.

## 4. How did static analysis improve your program, and what did you learn?

Static analysis helped me identify and correct issues in the assigned bike-share station manager. I learned how to set up a Python virtual environment, run Pylint, Bandit, and Flake8, document findings, and use Git to record changes. I also learned that static analysis complements testing because a program can pass static checks and still contain functional errors.