"""Manage stations in a simple in-memory bike-share network."""

import secrets
import sqlite3


DATABASE = sqlite3.connect(":memory:")
DATABASE.execute(
    """
    CREATE TABLE stations (
        id INTEGER PRIMARY KEY,
        name TEXT,
        capacity INTEGER,
        bikes INTEGER
    )
    """
)


def add_station(name, capacity, bikes, log=None):
    """Register a station and return the updated station log."""
    if log is None:
        log = []

    DATABASE.execute(
        "INSERT INTO stations (name, capacity, bikes) VALUES (?, ?, ?)",
        (name, capacity, bikes),
    )
    log.append(name)
    return log


def rent_bike(station_id):
    """Rent a bike if the requested station has one available."""
    row = DATABASE.execute(
        "SELECT bikes FROM stations WHERE id = ?",
        (station_id,),
    ).fetchone()

    if row is not None and row[0] > 0:
        DATABASE.execute(
            "UPDATE stations SET bikes = bikes - 1 WHERE id = ?",
            (station_id,),
        )
        return True

    return False


def unlock_pin():
    """Generate a four-digit PIN using a security-oriented random source."""
    return secrets.randbelow(9000) + 1000


def full_stations():
    """Return the names of stations whose bike count equals capacity."""
    stations = DATABASE.execute(
        "SELECT name FROM stations WHERE bikes = capacity"
    ).fetchall()

    return [station[0] for station in stations]


def reset_station(station_id):
    """Reset the bike count at the specified station to zero."""
    DATABASE.execute(
        "UPDATE stations SET bikes = 0 WHERE id = ?",
        (station_id,),
    )


def has_bikes(station_id):
    """Return whether the specified station has bikes available."""
    row = DATABASE.execute(
        "SELECT bikes FROM stations WHERE id = ?",
        (station_id,),
    ).fetchone()

    return row is not None and row[0] is not None and row[0] > 0


def main():
    """Run a short demonstration of the bike-share manager."""
    add_station("Central Park", 10, 10)
    add_station("Metro Gate", 8, 2)

    print(rent_bike(2), rent_bike(9) is False)
    print(unlock_pin(), full_stations(), has_bikes(2))

    reset_station(1)


if __name__ == "__main__":
    main()